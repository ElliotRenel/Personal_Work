#include "game.h"
#include <stdlib.h>
#include "game_io.h"

game load_game(char* filename){
  return NULL;
}

void save_game(cgame g, char* filename){
}
